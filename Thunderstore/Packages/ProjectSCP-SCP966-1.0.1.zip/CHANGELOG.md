## 1.0.0

- Initial release

## 1.0.1
- Fixed a bug where your weight would just infinitly go up
- Modified ReadMe.md
- Prepared Scan if needed